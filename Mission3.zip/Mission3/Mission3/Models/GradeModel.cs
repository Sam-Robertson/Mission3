﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;
namespace Mission3.Models
{
    public class GradeModel
    {
        [Range(0, 100)]
        public int Assignment { get; set; }
        [Range(0, 100)]
        public int GroupProj { get; set; }
        [Range(0, 100)]
        public int Quiz { get; set; }
        [Range(0, 100)]
        public int Exam { get; set; }
        [Range(0, 100)]
        public int Intex { get; set; }

    }
}

//public class Student
//{
//    public int StudentId { get; set; }

//    [Required]
//    public string StudentName { get; set; }

//   
//}
