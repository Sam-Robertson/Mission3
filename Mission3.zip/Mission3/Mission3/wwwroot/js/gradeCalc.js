﻿$("#btnSend").click(function () {


    var assignment = $("#assignment").val() * .55;
    var groupProj = $("#groupProj").val() * .05;
    var quiz = $("#quiz").val() * .1;
    var exam = $("#exam").val() * .2;
    var intex = $("#intex").val() * .1;
    console.log(assignment)
    console.log(groupProj)
    console.log(quiz)
    console.log(exam)
    console.log(intex)

    var finalPercent = (assignment + groupProj + quiz + exam + intex).toFixed(1)
    console.log(finalPercent);
    var finalGrade;

    if (finalPercent >= 94) {
        finalGrade = 'A'
    }
    else if (finalPercent >= 90) {
        finalGrade = 'A-'
    }
    else if (finalPercent >= 87) {
        finalGrade = 'B+'
    }
    else if (finalPercent >= 84) {
        finalGrade = 'B'
    }
    else if (finalPercent >= 80) {
        finalGrade = 'B-'
    }
    else if (finalPercent >= 77) {
        finalGrade = 'C+'
    }
    else if (finalPercent >= 74) {
        finalGrade = 'C'
    }
    else if (finalPercent >= 70) {
        finalGrade = 'C-'
    }
    else if (finalPercent < 70) {
        finalGrade = 'E'
    }

    alert("Your final percent was: " + finalPercent +
        " Your final grade was: " + finalGrade)

})